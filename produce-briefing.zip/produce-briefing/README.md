# 🥦 Québec Fresh Produce — Weekly Market Briefing

A self-hosted web app that generates a weekly fresh produce industry briefing for Québec, powered by the Anthropic API with live web search.

---

## Requirements

- [Node.js](https://nodejs.org/) v18 or higher
- An [Anthropic API key](https://console.anthropic.com/)

---

## Quick Start (Local)

```bash
# 1. Set your API key
export ANTHROPIC_API_KEY=sk-ant-...

# 2. Start the server
node server.js

# 3. Open in browser
# http://localhost:3000
```

---

## Deploy to Railway (Free, Recommended)

1. Create a free account at [railway.app](https://railway.app)
2. Click **New Project → Deploy from GitHub repo** (or use the Railway CLI)
3. Upload this folder, or push to a GitHub repo and connect it
4. In Railway project settings → **Variables**, add:
   ```
   ANTHROPIC_API_KEY = sk-ant-your-key-here
   PORT = 3000
   ```
5. Railway will auto-detect Node.js and deploy — you'll get a public URL like `https://produce-briefing.up.railway.app`
6. **Share that URL in Teams** ✅

---

## Deploy to Render (Free Tier)

1. Create a free account at [render.com](https://render.com)
2. New → **Web Service** → connect your GitHub repo
3. Set:
   - Build Command: *(leave blank)*
   - Start Command: `node server.js`
4. Add environment variable: `ANTHROPIC_API_KEY`
5. Deploy → share the `https://your-app.onrender.com` URL

---

## Deploy to a VPS / Your Own Server

```bash
# Install Node.js, clone/upload this folder, then:
export ANTHROPIC_API_KEY=sk-ant-...
node server.js

# To keep it running (using pm2):
npm install -g pm2
pm2 start server.js --name produce-briefing
pm2 save
```

---

## How It Works

- `server.js` — Node.js HTTP server (no external dependencies)
  - Serves static files from `public/`
  - Exposes `POST /api/briefing` which proxies to Anthropic API with an agentic web-search loop
  - Your API key never touches the browser
- `public/index.html` — Frontend UI
  - Caches the weekly briefing in `localStorage` (one API call per week per browser)
  - "↻ Refresh anyway" forces a new generation

---

## Project Structure

```
produce-briefing/
├── server.js          ← Backend (API proxy + static file server)
├── package.json
├── README.md
└── public/
    └── index.html     ← Frontend UI
```

---

## Customizing

To adjust markets, priorities, or prompts, edit the `SYSTEM_PROMPT` and `getUserPrompt()` function in `public/index.html`.
